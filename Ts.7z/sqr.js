var sq;
(function (sq) {
    function area(a) {
        return (a * a);
    }
    sq.area = area;
})(sq || (sq = {}));
