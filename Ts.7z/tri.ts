namespace triangle{
    export function area(a:number,b:number):number{
return(0.5*a*b);
    }
}