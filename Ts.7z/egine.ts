interface Engine{
    rmp():void;
    temperature():void;
    speedometer():void;
}
class Dodge implements Engine{
    rmp(): void {
        console.log("Rmp is 1000");
    }
    temperature(): void {
        console.log("the temp is 20");
    }
    speedometer(): void {
        console.log("the speed id 220km/h");
    }
    
}
class Bmw implements Engine{
    rmp(): void {
        console.log("the rpm is 800");
    }
    temperature(): void {
        console.log("the temp is 18");
    }
    speedometer(): void {
        console.log("the speed is 200km/h");
    }
    
}
var obj:Engine= new Bmw();
obj.rmp();
obj.speedometer();
obj.temperature();
var dodge:Engine= new Dodge();
dodge.temperature();
dodge.rmp();
dodge.speedometer();
