"use strict";
exports.__esModule = true;
//import {banner, disPage} from "./a";
var a_1 = require("./a");
console.log(a_1.banner);
console.log(a_1.disPage("subi"));
