"use strict";
exports.__esModule = true;
exports.disPage = exports.banner = void 0;
exports.banner = "This banner is used by all page";
function disPage(my) {
    return my;
}
exports.disPage = disPage;
