var Employe = /** @class */ (function () {
    function Employe() {
    }
    Employe.prototype.getEmp = function (ename) {
        this.ename = ename;
    };
    Employe.prototype.printEmp = function () {
        console.log(this.ename);
    };
    return Employe;
}());
var erf = new Employe();
erf.getEmp("subi");
erf.printEmp();
