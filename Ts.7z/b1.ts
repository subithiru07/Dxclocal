//import {Trainee} from "./a1";
import * as some from "./a1";
var obj= new some.Trainee(10);
obj.disp();
some.restparam(12,"subi","thiru");