namespace sq{
    export function area(a:number): number{
        return(a*a);
        
    }
}