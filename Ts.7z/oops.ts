class Employe{
    
    ename:string;
    private salary:number;
    getEmp(ename:string):void{
        this.ename=ename;
    }
    printEmp():void{
      console.log(this.ename); 
    }
}
var erf= new Employe();
erf.getEmp("subi");
erf.printEmp();