abstract class manager{
    constructor(){
console.log("abtract Manager class constructor");
    }

abstract doWork():void;
abstract printDet():void;

}
class Employee extends manager{
    printDet(): void {
        console.log("print");
    }
    eid:number;
    ename:string;
    doWork(): void {
        console.log("abstruct meth");
    }
    
    constructor(id:number,name:string){
super();
        this.eid=id;
this.ename=name;
    }
    getData():void{
        console.log(this.ename +" "+this.eid);
    }
}

var e= new Employee(10,"thiru");
e.doWork();
e.getData();
e.printDet();
var ob :manager=new Employee(20,"subi");
ob.printDet();
ob.doWork();