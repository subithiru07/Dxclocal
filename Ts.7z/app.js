/// <reference path="sqr.ts"/>
/// <reference path="tri.ts"/>
var test = /** @class */ (function () {
    function test() {
    }
    test.prototype.get = function () {
        console.log(sq.area(10));
        console.log(triangle.area(10, 30));
    };
    return test;
}());
var obj = new test();
obj.get();
