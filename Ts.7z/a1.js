"use strict";
exports.__esModule = true;
exports.restparam = exports.Trainee = void 0;
var Trainee = /** @class */ (function () {
    function Trainee(id) {
        this.eid = id;
    }
    Trainee.prototype.disp = function () {
        console.log(this.eid);
    };
    return Trainee;
}());
exports.Trainee = Trainee;
function restparam(a) {
    var str = [];
    for (var _i = 1; _i < arguments.length; _i++) {
        str[_i - 1] = arguments[_i];
    }
    for (var _a = 0, str_1 = str; _a < str_1.length; _a++) {
        var s = str_1[_a];
        console.log(s);
    }
}
exports.restparam = restparam;
