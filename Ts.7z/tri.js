var triangle;
(function (triangle) {
    function area(a, b) {
        return (0.5 * a * b);
    }
    triangle.area = area;
})(triangle || (triangle = {}));
