var Dodge = /** @class */ (function () {
    function Dodge() {
    }
    Dodge.prototype.rmp = function () {
        console.log("Rmp is 1000");
    };
    Dodge.prototype.temperature = function () {
        console.log("the temp is 20");
    };
    Dodge.prototype.speedometer = function () {
        console.log("the speed id 220km/h");
    };
    return Dodge;
}());
var Bmw = /** @class */ (function () {
    function Bmw() {
    }
    Bmw.prototype.rmp = function () {
        console.log("the rpm is 800");
    };
    Bmw.prototype.temperature = function () {
        console.log("the temp is 18");
    };
    Bmw.prototype.speedometer = function () {
        console.log("the speed is 200km/h");
    };
    return Bmw;
}());
var obj = new Bmw();
obj.rmp();
obj.speedometer();
obj.temperature();
var dodge = new Dodge();
dodge.temperature();
dodge.rmp();
dodge.speedometer();
