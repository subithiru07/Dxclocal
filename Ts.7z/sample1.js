// declaring types
function printDet() {
    var arr;
    arr = ['subi', 'venky'];
    for (var _i = 0, arr_1 = arr; _i < arr_1.length; _i++) {
        var s = arr_1[_i];
        console.log(s);
    }
    var some;
    some = 100;
    console.log("some " + some);
    var name = "subim";
    var age = 10;
    var edesc = true;
    console.log("welcome to Typescript");
    console.log("name " + name);
    console.log("age " + age);
    console.log("any info " + edesc);
}
function getData() {
    return 1001;
}
printDet();
console.log("------------------------------");
var temp = getData();
console.log(temp);
