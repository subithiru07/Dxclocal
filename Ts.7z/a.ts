export var banner:string="This banner is used by all page";
export function disPage(my:string):string
{
return my
}