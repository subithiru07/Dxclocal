var Remote = /** @class */ (function () {
    function Remote() {
    }
    Remote.prototype.off = function () {
        console.log("Off");
    };
    Remote.prototype.on = function () {
        console.log("On");
    };
    return Remote;
}());
var obj = new Remote();
obj.off();
obj.on();
