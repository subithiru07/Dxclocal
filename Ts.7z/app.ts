/// <reference path="sqr.ts"/>
/// <reference path="tri.ts"/>
class test{
get():void{
 console.log(sq.area(10));
 console.log(triangle.area(10,30));
}
}
var obj=new test();
obj.get();