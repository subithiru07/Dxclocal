// declaring types
/*var name:string;
var age :number;
var edesc:any;*/
console.log("welcome to Typescript");