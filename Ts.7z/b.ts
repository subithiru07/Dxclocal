//import {banner, disPage} from "./a";
import {banner as b, disPage} from "./a";

console.log(b);
console.log(disPage("subi"));