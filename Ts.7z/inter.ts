interface Device{
    off():void;
    on():void;
    switch?():void;


}
class Remote implements Device{
    off(): void {
        console.log("Off");
    }
    on(): void {
        console.log("On");
    }

}

var obj:Device=new Remote();
obj.off();
obj.on();