export class Trainee{
    eid:number;
    constructor(id:number){
this.eid=id;
    }
    disp():void{
        console.log(this.eid);
    }
}
export function restparam(a:number,... str:string[]):void{
for(var s of str){
    console.log(s);
}
}