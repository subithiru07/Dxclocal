var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var manager = /** @class */ (function () {
    function manager() {
        console.log("abtract Manager class constructor");
    }
    return manager;
}());
var Employee = /** @class */ (function (_super) {
    __extends(Employee, _super);
    function Employee(id, name) {
        var _this = _super.call(this) || this;
        _this.eid = id;
        _this.ename = name;
        return _this;
    }
    Employee.prototype.printDet = function () {
        console.log("print");
    };
    Employee.prototype.doWork = function () {
        console.log("abstruct meth");
    };
    Employee.prototype.getData = function () {
        console.log(this.ename + " " + this.eid);
    };
    return Employee;
}(manager));
var e = new Employee(10, "thiru");
e.doWork();
e.getData();
e.printDet();
var ob = new Employee(20, "subi");
ob.printDet();
ob.doWork();
