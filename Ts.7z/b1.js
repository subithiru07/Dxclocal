"use strict";
exports.__esModule = true;
//import {Trainee} from "./a1";
var some = require("./a1");
var obj = new some.Trainee(10);
obj.disp();
some.restparam(12, "subi", "thiru");
