// declaring types

            


           function printDet():void
           {
var arr:string[];
arr=['subi','venky'];
for(var s of arr){
    console.log(s);
}
let some:number;
    some=100;       
console.log("some "+some);
var name:string="subim";
 var age :number=10;
 var edesc:any=true;
console.log("welcome to Typescript");
console.log("name "+name);
console.log("age "+age);

console.log("any info "+edesc);
          

}


function getData():number{
return 1001;
}
printDet();
console.log("------------------------------");
var temp=getData();
console.log(temp);